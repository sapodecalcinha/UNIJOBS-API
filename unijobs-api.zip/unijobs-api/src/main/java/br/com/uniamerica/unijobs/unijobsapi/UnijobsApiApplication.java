package br.com.uniamerica.unijobs.unijobsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnijobsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnijobsApiApplication.class, args);
	}

}
