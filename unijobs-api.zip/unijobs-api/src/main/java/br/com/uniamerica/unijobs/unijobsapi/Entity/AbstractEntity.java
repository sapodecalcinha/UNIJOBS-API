package br.com.uniamerica.unijobs.unijobsapi.Entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@MappedSuperclass
public abstract class AbstractEntity {
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Id
    @Getter @Setter
    @Column(name = "id", nullable = false, unique = true)
    private long id;

    @Getter @Setter
    @Column(name = "ativo", nullable = false)
    private boolean ativo;

}
