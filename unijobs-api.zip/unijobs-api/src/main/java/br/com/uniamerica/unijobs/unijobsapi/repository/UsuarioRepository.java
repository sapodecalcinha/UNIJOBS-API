package br.com.uniamerica.unijobs.unijobsapi.repository;

import br.com.uniamerica.unijobs.unijobsapi.Entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario,Long> {

    @Query("from Usuario where ativo=: ativo")
    public List<Usuario> findByAtivoTrue();

    @Query("from Usuario where nome=: nome")
    public List<Usuario> findByNome(final String nome);

    @Query("from Usuario where ra=: ra")
    public List<Usuario> findByRa(final int ra );

    @Query("from Usuario where instagram=: instagram")
    public List<Usuario> findByInstagram(final String instagram);

    @Query("from Usuario where facebook=: facebook")
    public List<Usuario> findByFacebook(final String facebook);

    @Query("from Usuario where telefone=: telefone")
    public List<Usuario> findByTelefone(final int telefone);

}
