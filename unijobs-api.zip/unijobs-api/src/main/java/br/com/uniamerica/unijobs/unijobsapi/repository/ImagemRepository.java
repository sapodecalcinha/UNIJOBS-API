package br.com.uniamerica.unijobs.unijobsapi.repository;

import br.com.uniamerica.unijobs.unijobsapi.Entity.Imagem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ImagemRepository extends JpaRepository<Imagem,Long> {

  @Query("from Imagem where ativo=: ativo")
  public List<Imagem> findByAtivoTrue();

  @Query("from Imagem where url=: url")
  public List<Imagem> findByUrl(final String url);

  @Query("from Imagem where ordem=: ordem")
  public List<Imagem> findByOrdem(final int ordem);



}
