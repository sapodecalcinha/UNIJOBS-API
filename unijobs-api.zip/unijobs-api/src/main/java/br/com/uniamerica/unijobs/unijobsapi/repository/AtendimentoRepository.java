package br.com.uniamerica.unijobs.unijobsapi.repository;

import br.com.uniamerica.unijobs.unijobsapi.Entity.Atendimento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AtendimentoRepository extends JpaRepository<Atendimento,Long> {

 @Query("from Atendimento where ativo=: ativo")
 public List<Atendimento> findByAtivoTrue();

 @Query("from Atendimento where hrInicio=: hrInicio")
 public List<Atendimento> findByHrInicio(final LocalDateTime hrInicio);

 @Query("from Atendimento where hrInicio=: hrinicio")
 public List<Atendimento> findByHrFinal(final LocalDateTime hrFinal);

 @Query("from Atendimento where domingo=: domingo")
 public List<Atendimento> findByDomingo(final boolean domingo);

 @Query("from Atendimento where segunda=: segunda")
 public List<Atendimento> findBySegunda(final boolean segunda);

 @Query("from Atendimento where terca=: terca")
 public List<Atendimento>  findByTerca(final boolean terca);

 @Query("from Atendimento where quarta=: quarta")
 public List<Atendimento> findByQuarta(final boolean quarta);

 @Query("from Atendimento where quinta=: quinta")
 public List<Atendimento> findByQuinta(final boolean quinta);

 @Query("from Atendimento where sexta=: sexta")
 public List<Atendimento> findBtSexta(final boolean sexta);

 @Query("from Atendimento where sabado=: sabado")
 public List<Atendimento> findBySabado(final boolean sabado);

}
