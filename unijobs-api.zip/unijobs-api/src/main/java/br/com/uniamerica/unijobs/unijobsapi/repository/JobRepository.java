package br.com.uniamerica.unijobs.unijobsapi.repository;

import br.com.uniamerica.unijobs.unijobsapi.Entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import java.math.BigDecimal;
import java.util.List;

@Repository
public interface JobRepository extends JpaRepository<Job,Long> {

  @Query("from Job where ativo=: ativo")
  public List<Job> findByAtivoTrue();

  @Query("from Job where titulo=: titulo")
  public List<Job> findByTitulo(final String titulo);

  @Query("from Job where atendimento=: atendimento")
  public List<Job> findByAtendimento(final Atendimento atendimento);

  @Query("from Job where precoMinimo=: precoMinimo")
  public List<Job> findByPreMinimo(final BigDecimal precoMinimo);

  @Query("from Job where precoMaximo=: precoMaximo")
  public List<Job> findByPrecoMaximo(final BigDecimal precoMaximo);

  @Query("from Job where tipo=: tipo")
  public List<Job> findByTipo(final Tipo tipo);

  @Query("from Job where descricao=: descricao")
  public List<Job> findByDescricao(final String descricao);

  @Query("from Job where usuario=: usuario")
  public List<Job> findByUsuario(final Usuario usuario);

  @Query("from Job where endereco=: endereco")
  public List<Job> findByEndereco(final Endereco endereco);

  @Query("from Job where imagem=: imagem")
  public List<Job> findByImagem(final Imagem imagem);



}
