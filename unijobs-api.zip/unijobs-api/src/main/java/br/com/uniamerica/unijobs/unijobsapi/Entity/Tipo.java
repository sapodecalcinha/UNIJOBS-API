package br.com.uniamerica.unijobs.unijobsapi.Entity;

public enum Tipo {
    GASTRONOMIA,
    EDUCACAO,
    ARTESANATO,
    MANUTENCAO,
    BARBEARIA,
    OUTROS;
}
